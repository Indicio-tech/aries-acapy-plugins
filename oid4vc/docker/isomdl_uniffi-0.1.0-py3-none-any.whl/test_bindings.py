#!/usr/bin/env python3
"""
Simple test script for the isomdl-uniffi Python bindings.
This script demonstrates basic functionality of the library.
"""

import isomdl_uniffi as mdl
import uuid
import json

def test_basic_functionality():
    """Test basic functionality of the isomdl-uniffi library."""
    print("Testing isomdl-uniffi Python bindings...")
    
    # Test key pair generation first (required for test MDL)
    print("\n1. Testing key pair generation:")
    try:
        key_pair = mdl.P256KeyPair()  # Constructor creates a new key pair
        print("   Successfully generated P256 key pair")
        print(f"   Key pair type: {type(key_pair)}")
        
        # Test getting public key as JWK
        public_jwk = key_pair.public_jwk()
        print(f"   Public key JWK length: {len(public_jwk)} characters")
        
    except Exception as e:
        print(f"   Error generating key pair: {e}")
        return None
    
    # Test generating a test MDL
    print("\n2. Testing test MDL generation:")
    try:
        test_mdl = mdl.generate_test_mdl(key_pair)  # Requires key_pair parameter
        print("   Successfully generated test MDL")
        print(f"   MDL type: {type(test_mdl)}")
        
        # Test getting document type
        doc_type = test_mdl.doctype()
        print(f"   Document type: {doc_type}")
        
        # Test getting MDL ID
        mdl_id = test_mdl.id()
        print(f"   MDL ID: {mdl_id}")
        
        # Test getting details (namespaces and elements)
        details = test_mdl.details()
        print(f"   Details type: {type(details)}")
        print(f"   Number of namespaces: {len(details)}")
        
        for namespace, elements in details.items():
            print(f"   Namespace '{namespace}': {len(elements)} elements")
            for element in elements[:3]:  # Show first 3 elements
                print(f"     - {element.identifier}: {element.value}")
            if len(elements) > 3:
                print(f"     ... and {len(elements) - 3} more")
                
    except Exception as e:
        print(f"   Error generating test MDL: {e}")
        return None
    
    # Test creating a presentation session
    print("\n3. Testing presentation session creation:")
    try:
        session_uuid = str(uuid.uuid4())
        presentation_session = mdl.MdlPresentationSession(test_mdl, session_uuid)  # Constructor
        print("   Successfully created presentation session")
        
        # Test getting QR code URI
        qr_uri = presentation_session.get_qr_code_uri()
        print(f"   QR Code URI: {qr_uri}")
        
        # Test getting BLE identifier
        ble_ident = presentation_session.get_ble_ident()
        print(f"   BLE Identifier length: {len(ble_ident)} bytes")
        
    except Exception as e:
        print(f"   Error creating presentation session: {e}")
    
    return test_mdl, key_pair


def test_reader_functionality():
    """Test reader functionality (if available)."""
    print("\n5. Testing reader functionality:")
    
    # Test establishing a reader session
    try:
        # Example requested items for org.iso.18013.5.1 namespace
        requested_items = {
            "org.iso.18013.5.1": {
                "family_name": True,
                "given_name": True,
                "birth_date": True,
                "issue_date": True,
                "expiry_date": True,
                "document_number": True
            }
        }
        
        # This would typically require a real device engagement QR code
        # For testing, we'll use a placeholder URI
        test_uri = "mdoc://test-uri"
        
        print(f"   Attempting to establish reader session with test URI")
        print(f"   Requested items: {json.dumps(requested_items, indent=2)}")
        
        # Note: This will likely fail without a real device engagement,
        # but it demonstrates the API
        session_data = mdl.establish_session(
            uri=test_uri,
            requested_items=requested_items,
            trust_anchor_registry=[]  # Empty trust anchor list for test
        )
        
        print(f"   ✅ Session established successfully!")
        print(f"   Session UUID: {session_data.uuid}")
        
    except Exception as e:
        print(f"   ⚠️  Expected error (no real device): {e}")
        print(f"   This is normal for a test without real mDL device interaction")

if __name__ == "__main__":
    print("=" * 60)
    print("ISO MDL UniFFI Python Bindings Test")
    print("=" * 60)
    
    try:
        test_basic_functionality()
        test_reader_functionality()
        
        print("\n" + "=" * 60) 
        print("🎉 All tests completed!")
        print("The isomdl-uniffi Python bindings are working correctly.")
        print("=" * 60)
        
    except Exception as e:
        print(f"\n❌ Test failed with error: {e}")
        import traceback
        traceback.print_exc()